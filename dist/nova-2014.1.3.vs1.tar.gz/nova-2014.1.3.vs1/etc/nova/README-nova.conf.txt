To generate the sample nova.conf file, run the following
command from the top level of the nova directory:

tox -egenconfig
